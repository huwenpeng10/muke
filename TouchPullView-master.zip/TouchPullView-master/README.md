#### 效果图：
![](http://p07lh1fh6.bkt.clouddn.com/touch_demo.gif-sy)

#### 实现原理分析详见博客：[www.huangjie.name](http://www.huangjie.name/%E4%B8%80%E7%9C%8B%E5%B0%B1%E6%87%82%E7%9A%84%E8%87%AA%E5%AE%9A%E4%B9%89%E9%A1%B6%E9%83%A8%E7%B2%98%E6%80%A7%E4%B8%8B%E6%8B%89%E6%8E%A7%E4%BB%B6TouchPullView%E5%85%A8%E9%9D%A2%E5%89%96%E6%9E%90.html)
