/*
 * Copyright (c) 2015 Zhang Hai <Dreaming.in.Code.ZH@Gmail.com>
 * All Rights Reserved.
 */

package me.zhanghai.android.douya.notification.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.zhanghai.android.douya.R;
import me.zhanghai.android.douya.eventbus.EventBusUtils;
import me.zhanghai.android.douya.eventbus.NotificationUpdatedEvent;
import me.zhanghai.android.douya.network.api.ApiError;
import me.zhanghai.android.douya.network.api.info.frodo.Notification;
import me.zhanghai.android.douya.notification.content.NotificationListResource;
import me.zhanghai.android.douya.ui.LoadMoreAdapter;
import me.zhanghai.android.douya.ui.NoChangeAnimationItemAnimator;
import me.zhanghai.android.douya.ui.OnVerticalScrollListener;
import me.zhanghai.android.douya.util.LogUtils;
import me.zhanghai.android.douya.util.ToastUtils;
import me.zhanghai.android.douya.util.ViewUtils;

public class NotificationListFragment extends Fragment implements NotificationListResource.Listener,
        NotificationAdapter.Listener {

    @BindView(R.id.swipe_refresh)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.notification_list)
    RecyclerView mNotificationList;
    @BindView(R.id.progress)
    ProgressBar mProgress;

    private NotificationListResource mNotificationListResource;

    private NotificationAdapter mNotificationAdapter;
    private LoadMoreAdapter mAdapter;

    private Listener mListener;

    public static NotificationListFragment newInstance() {
        //noinspection deprecation
        return new NotificationListFragment();
    }

    /**
     * @deprecated Use {@link #newInstance()} instead.
     */
    public NotificationListFragment() {}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.notification_list_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ButterKnife.bind(this, view);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        mNotificationListResource = NotificationListResource.attachTo(this);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });

        mNotificationList.setHasFixedSize(true);
        mNotificationList.setItemAnimator(new NoChangeAnimationItemAnimator());
        Activity activity = getActivity();
        mNotificationList.setLayoutManager(new LinearLayoutManager(activity));
        mNotificationAdapter = new NotificationAdapter(mNotificationListResource.get(), activity);
        mNotificationAdapter.setListener(this);
        mAdapter = new LoadMoreAdapter(R.layout.load_more_item, mNotificationAdapter);
        mNotificationList.setAdapter(mAdapter);
        mNotificationList.addOnScrollListener(new OnVerticalScrollListener() {
            @Override
            public void onScrolledToBottom() {
                mNotificationListResource.load(true);
            }
        });

        updateRefreshing();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        mNotificationListResource.detach();
    }

    @Override
    public void onLoadNotificationListStarted(int requestCode) {
        updateRefreshing();
    }

    @Override
    public void onLoadNotificationListFinished(int requestCode) {
        updateRefreshing();
    }

    @Override
    public void onLoadNotificationListError(int requestCode, ApiError error) {
        LogUtils.e(error.toString());
        Activity activity = getActivity();
        ToastUtils.show(ApiError.getErrorString(error, activity), activity);
    }

    @Override
    public void onNotificationListChanged(int requestCode, List<Notification> newNotificationList) {
        mNotificationAdapter.replace(newNotificationList);
        onNotificationListUpdated();
    }

    @Override
    public void onNotificationListAppended(int requestCode,
                                           List<Notification> appendedNotificationList) {
        mNotificationAdapter.addAll(appendedNotificationList);
        onNotificationListUpdated();
    }

    @Override
    public void onNotificationChanged(int requestCode, int position, Notification newNotification) {
        mNotificationAdapter.set(position, newNotification);
        onNotificationListUpdated();
    }

    @Override
    public void onNotificationRemoved(int requestCode, int position) {
        mNotificationAdapter.remove(position);
        onNotificationListUpdated();
    }

    private void updateRefreshing() {
        boolean loading = mNotificationListResource.isLoading();
        boolean empty = mNotificationListResource.isEmpty();
        boolean loadingMore = mNotificationListResource.isLoadingMore();
        mSwipeRefreshLayout.setRefreshing(loading && (mSwipeRefreshLayout.isRefreshing() || !empty)
                && !loadingMore);
        ViewUtils.setVisibleOrGone(mProgress, loading && empty);
        mAdapter.setProgressVisible(loading && !empty && loadingMore);
    }

    @Override
    public void onMarkNotificationAsRead(Notification notification) {
        notification.read = true;
        EventBusUtils.postAsync(new NotificationUpdatedEvent(notification, this));
    }

    public int getUnreadNotificationCount() {
        int count = 0;
        for (Notification notification : mNotificationAdapter.getList()) {
            if (!notification.read) {
                ++count;
            }
        }
        return count;
    }

    public void refresh() {
        mNotificationListResource.load(false);
    }

    public void setListener(Listener listener) {
        mListener = listener;
    }

    private void onNotificationListUpdated() {
        if (mListener != null) {
            mListener.onUnreadNotificationUpdate(getUnreadNotificationCount());
        }
    }

    public interface Listener {
        void onUnreadNotificationUpdate(int count);
    }
}
