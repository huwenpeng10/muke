package wuziqi.cbt.com.wuziqi;

/**
 * Created by caobotao on 16/3/31.
 */
public interface OnGameStatusChangeListener {
    void onGameOver(int gameWinResult);//游戏结束
}
