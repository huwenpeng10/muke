package app.wuxl.com.searchphone.mvp;

/**
 * Loading基类
 * Author:wuxianglong;
 * Time:2017/8/1.
 */
public interface MvpLoadingView {

    void showLoading();

    void hidenLoading();


}
